﻿using System;
using System.Security.Cryptography; // needed for HMACSHA256
using System.Collections.Generic;
using System.Net;
using System.IO;
using System.Text;
using Newtonsoft.Json.Linq; // Right-click on References - Manage NuGet Package - search Json.NET


// A simple C# .NET console REST Web Request console application 
// Code was written from HttpWebRequest Microsoft documentation and examples
// A POST request to test the connectivity and authorization to the World-Check One API webserver
//
// Brian Bourgault 03/24/2017
namespace ConsoleApplication3
{
    class WC1PostRequest
    {
        static void Main(string[] args)
        {
            DateTime dateValue =  DateTime.UtcNow; // get the datetime NOW GMT

            string date = dateValue.ToString("R"); // WC1 header requires GMT datetime stamp
            //Console.WriteLine(date);
            //set host and credentials to the WC1 API Pilot server WC1SampleClientAPI account
            string apikey = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
            string apisecret = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";  
            string gatewayurl = "/v1/";
            string gatewayhost = "rms-world-check-one-api-pilot.thomsonreuters.com";
            // Here is where you enter your api keys
            //string apikey = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
            //string apisecret = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
            string requestendpoint = "https://rms-world-check-one-api-pilot.thomsonreuters.com/v1/cases";

            string postData = "{\"secondaryFields\":[],\"entityType\":\"INDIVIDUAL\",\"customFields\":[],\"groupId\":\"418f28a7-b9c9-4ae4-8530-819c61b1ca6c\",\"providerTypes\":[\"WATCHLIST\"],\"name\":\"乔治布什\"}";

            //Console.WriteLine(postData.Length);

            string msg = postData; 
            //Console.WriteLine(msg);
            UTF8Encoding encoding = new UTF8Encoding();
            byte[] byte1 = encoding.GetBytes(postData);
            
                       // Assemble the POST request - NOTE every character including spaces have to be EXACT 
                       // for the API server to decode the authorization signature       
                       string dataToSign = "(request-target): post " + gatewayurl + "cases\n" +
                           "host: " + gatewayhost + "\n" +   // no https only the host name
                           "date: " + date + "\n" +          // GMT date as a string
                           "content-type: " + "application/json" + "\n" +
                           "content-length: " + byte1.Length + "\n" +
                            msg;

            Console.WriteLine("---api secret---");
            Console.WriteLine(apisecret);
            Console.WriteLine("---dataToSign---");
            Console.WriteLine(dataToSign);
            Console.WriteLine("string hmac = generateAuthHeader(dataToSign, apisecret);");
            // The Request and API secret are now combined and encrypted
            string hmac = generateAuthHeader(dataToSign, apisecret);
            
            // Assemble the authorization string - This needs to match the dataToSign elements 
            // i.e. requires  host date content-type content-length
            //- NOTE every character including spaces have to be EXACT else decryption will fail with 401 Unauthorized
            string authorisation = "Signature keyId=\"" + apikey + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\"" + hmac + "\"";



            Console.WriteLine("---Hmac---");
            Console.WriteLine(hmac);
            //Console.WriteLine(authorisation);

            // Send the Request to the API server
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(requestendpoint);
            // Set the Headers
            WebReq.Method = "POST";
            WebReq.Headers.Add("Authorization", authorisation);
            WebReq.Headers.Add("Cache-Control", "no-cache");
            WebReq.ContentLength = msg.Length;
            WebReq.Date = dateValue; // use datetime value GMT time
            // Set the content type of the data being posted.
            WebReq.ContentType = "application/json";
            WebReq.ContentLength = byte1.Length;

            Stream newStream = WebReq.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);

            // Get the Response - Status OK
            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            // Status information about the request
            Console.WriteLine(WebResp.StatusCode);
            Console.WriteLine(WebResp.ResponseUri);

            // Get the Response data
            Stream Answer = WebResp.GetResponseStream();
            StreamReader _Answer = new StreamReader(Answer);
            string jsontxt = _Answer.ReadToEnd();

            // convert json text to a pretty printout
            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject(jsontxt); 
            var f = Newtonsoft.Json.JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented);
            Console.WriteLine(f);
            Console.WriteLine("Press any key");
            Console.ReadKey(); // pause for any key
        }

        // Combine the data signature and the API secret key to get the HMAC
        // This is the Microsoft HMACSHA256 code copied from the documentation
        public static string generateAuthHeader(string dataToSign, string apisecret)
            {
                byte[] secretKey = Encoding.UTF8.GetBytes(apisecret);
                HMACSHA256 hmac = new HMACSHA256(secretKey);
                hmac.Initialize();

                byte[] bytes = Encoding.UTF8.GetBytes(dataToSign);
                byte[] rawHmac = hmac.ComputeHash(bytes);
                Console.WriteLine("---rawHmac---");
                string hex = BitConverter.ToString(rawHmac).Replace("-","");
                Console.WriteLine(hex);
                return(Convert.ToBase64String(rawHmac));
            }
       
    }
}
