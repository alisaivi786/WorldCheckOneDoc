﻿using System;
using System.Security.Cryptography; // needed for HMACSHA256
using System.Collections.Generic;
using System.Net;
using System.IO;
using System.Text;
using Newtonsoft.Json; // Right-click on References - Manage NuGet Package - search Json.NET


// A simple C# .NET console REST Web Request console application 
// Code was written from HttpWebRequest Microsoft documentation and examples
// A GET request to test the connectivity and authorization to the World-Check One API webserver
// The groups endpoint returns all the groups premissioned for WC1 API account WC1SampleClientAPI
//
// Brian Bourgault 03/24/2017
namespace ConsoleApplication2
{
    class WC1GetRequest
    {
        static void Main(string[] args)
        {
            DateTime dateValue =  DateTime.UtcNow; // get the datetime NOW GMT
                     
            string date = dateValue.ToString("R"); // WC1 header requires GMT datetime stamp
            Console.WriteLine(date);
            //set host and credentials to the WC1 API Pilot server WC1SampleClientAPI account
            string gatewayurl = "/v1/";
            string gatewayhost = "rms-world-check-one-api-pilot.thomsonreuters.com";
            // Here is where you enter your api keys
            string apikey = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
            string apisecret = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
            string requestendpoint = "https://rms-world-check-one-api-pilot.thomsonreuters.com/v1/groups";

            // Assemble the GET request - NOTE every character including spaces have to be EXACT 
            // for the API server to decode the authorization signature       
            string dataToSign = "(request-target): get " + gatewayurl + "groups\n" +
                "host: " + gatewayhost + "\n" +   // no https only the host name
                "date: " + date;                  // GMT date as a string
            // The Request and API secret are now combined and encrypted
            string hmac = generateAuthHeader(dataToSign, apisecret);
            
            // Assemble the authorization string - This needs to match the dataToSign elements 
            // i.e. requires ONLY host date (no content body for a GET request)
            //- NOTE every character including spaces have to be EXACT else decryption will fail with 401 Unauthorized
            string authorisation = "Signature keyId=\"" + apikey + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\"" + hmac + "\"";

            // Send the Request to the API server
            HttpWebRequest WebReq = (HttpWebRequest)WebRequest.Create(requestendpoint);
            // Set the Headers
            WebReq.Method = "GET";
            WebReq.Headers.Add("Authorization", authorisation);
            WebReq.Headers.Add("Cache-Control", "no-cache");
            WebReq.Date = dateValue; // use datetime value GMT time

            // Get the Response - Status OK
            HttpWebResponse WebResp = (HttpWebResponse)WebReq.GetResponse();
            // Status information about the request
            Console.WriteLine(WebResp.StatusCode);
            Console.WriteLine(WebResp.ResponseUri);

            // Get the Response data
            Stream Answer = WebResp.GetResponseStream();
            StreamReader _Answer = new StreamReader(Answer);
            string jsontxt = _Answer.ReadToEnd();

            // convert json text to a pretty printout
            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject(jsontxt); 
            var f = Newtonsoft.Json.JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented);
            Console.WriteLine(f);
            Console.WriteLine("Press any key");
            Console.ReadKey(); // pause for any key
        }

        // Combine the data signature and the API secret key to get the HMAC
        // This is the Microsoft HMACSHA256 code copied from the documentation
        public static string generateAuthHeader(string dataToSign, string apisecret)
            {
                byte[] secretKey = Encoding.UTF8.GetBytes(apisecret);
                HMACSHA256 hmac = new HMACSHA256(secretKey);
                hmac.Initialize();

                byte[] bytes = Encoding.UTF8.GetBytes(dataToSign);
                byte[] rawHmac = hmac.ComputeHash(bytes);
          
                return(Convert.ToBase64String(rawHmac));
            }
       
    }
}
