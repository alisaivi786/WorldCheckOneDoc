package APIrequests;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.databind.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;


import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
//import org.apache.commons.logging.*;
import org.json.*;

public class PostRequest {

    public static String generateAuthHeader(String dataToSign, String secret)
   {      
    String hash = "";
      try { 

    	  Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
    	  SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
    	  sha256_HMAC.init(secret_key);
    	  hash = Base64.encodeBase64String(sha256_HMAC.doFinal(dataToSign.getBytes()));
      }
      catch (Exception e){
    	  System.out.println("Error");
      }
    	return(hash);
   }
    

    // A simple request to create a Case using Http Post
    public static void main(String[] args) throws Exception {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        try {
        	Date now = new Date();
        	
        	//format for date string Mon, 27 Mar 2017 15:19:36 GMT 
        	DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
        	df.setTimeZone(TimeZone.getTimeZone("GMT"));
        	
        	String date = df.format(now);
            String gatewayurl = "/v1/";
            String gatewayhost = "rms-world-check-one-api-pilot.thomsonreuters.com";
            String apikey = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
            String apisecret = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
        	String groupid = "418f28a7-b9c9-4ae4-8530-819c61b1ca6c";

        	//create a JSON string 
        	String jsonBody =  "{\"secondaryFields\":[],\"entityType\":\"INDIVIDUAL\",\"customFields\":[],\"groupId\":\"418f28a7-b9c9-4ae4-8530-819c61b1ca6c\",\"providerTypes\":[\"WATCHLIST\"],\"name\":\"george bush\"}";
        	
        	// create a JSON object from the JSON string
        	JSONObject jo = new JSONObject(jsonBody);

        	//System.out.println(jo.toString());

        	String jlen = String.valueOf(jo.toString().length());
            String dataToSign = "(request-target): post " + gatewayurl + "cases\n" +
            		"host: " + gatewayhost + "\n" +
            		"date: " + date + "\n" +
            		"content-type: " +  "application/json" +"\n" + 
            		"content-length: " + jlen + "\n" + 
            		jo;
            
            String hmac = generateAuthHeader(dataToSign, apisecret);
            String authorisation = "Signature keyId=\"" + apikey  + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\"" + hmac + "\"";
            
            System.out.println(jlen);
            System.out.println(dataToSign);
        	//System.out.println(hmac);
        	System.out.println(authorisation);
        	String msg = jo.toString();
        	
            HttpPost httpPost = new HttpPost("https://rms-world-check-one-api-pilot.thomsonreuters.com/v1/cases");
                
            HttpEntity entity = new StringEntity(msg);
            httpPost.setEntity(entity);
            
            httpPost.addHeader("Date", date);
            httpPost.addHeader("Cache-Control", "no-cache");         
            httpPost.addHeader("Content-Type",  "application/json" );
            httpPost.addHeader("Authorization", authorisation);        
            
            // send the POST request
            CloseableHttpResponse response1 = httpclient.execute(httpPost);

            try {
            
                HttpEntity entity1 = response1.getEntity();
                System.out.println(response1.getStatusLine());
                
                String json = EntityUtils.toString(response1.getEntity());
                //System.out.println(entity1);
                // json string returned
                System.out.println(json);
                ObjectMapper mapper = new ObjectMapper();
                
                // printout in Pretty format
                Object jsonObj = mapper.readValue(json, Object.class);
                String indented = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonObj);
                System.out.println(indented);

                EntityUtils.consume(entity1);
                
            } 
            finally {
                response1.close();
            }


        } finally {
            httpclient.close();
        }
    }

}