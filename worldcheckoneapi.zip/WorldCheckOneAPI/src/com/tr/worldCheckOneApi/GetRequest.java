package com.tr.worldCheckOneApi;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.databind.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;


import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
//import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;


public class GetRequest {

    public static String generateAuthHeader(String dataToSign, String secret)
   {      
    String hash = "";
      try { 

    	  Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
    	  SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
    	  sha256_HMAC.init(secret_key);
    	  hash = Base64.encodeBase64String(sha256_HMAC.doFinal(dataToSign.getBytes()));
      }
      catch (Exception e){
    	  System.out.println("Error");
      }
    	return(hash);
   }
    
    // A simple request to create a Case using Http Get
    public static void main(String[] args) throws Exception {
        CloseableHttpClient httpclient = HttpClients.createDefault();
        try {
        	Date now = new Date();

        	//format for date string Mon, 27 Mar 2017 15:19:36 GMT 
        	DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
        	df.setTimeZone(TimeZone.getTimeZone("GMT"));

        	String date = df.format(now);
        	String gatewayurl = "/v1/";
            String gatewayhost = "rms-world-check-one-api-pilot.thomsonreuters.com";
            String apikey = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
            String apisecret = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
                  
            String dataToSign = "(request-target): get " + gatewayurl + "groups\n" +
           "host: " + gatewayhost + "\n" +
           "date: " + date;

            String hmac = generateAuthHeader(dataToSign, apisecret);
            String authorisation = "Signature keyId=\"" + apikey + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\"" + hmac + "\"";
            
            System.out.println(dataToSign);
        	System.out.println(hmac);
        	//System.out.println(authorisation);
            
            HttpGet httpGet = new HttpGet("https://rms-world-check-one-api-pilot.thomsonreuters.com/v1/groups");
            
            httpGet.addHeader("Authorization", authorisation);
            httpGet.addHeader("Cache-Control", "no-cache");
            httpGet.addHeader("date", date);
            
            CloseableHttpResponse response1 = httpclient.execute(httpGet);

            try {
            
                HttpEntity entity1 = response1.getEntity();
                System.out.println(response1.getStatusLine());
                
                String json = EntityUtils.toString(response1.getEntity());
                System.out.println(entity1);
                System.out.println(json);
                ObjectMapper mapper = new ObjectMapper();
                
                Object jsonObj = mapper.readValue(json, Object.class);
                String indented = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonObj);
                System.out.println(indented);

                EntityUtils.consume(entity1);
            } 
            finally {
                response1.close();
            }

        } finally {
            httpclient.close();
        }
    }

}