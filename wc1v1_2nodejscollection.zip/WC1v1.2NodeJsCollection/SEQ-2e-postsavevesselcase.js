// SEQ-2e-postsavevesselcase - HTTPS POST w/Body request & response
//
// synopsis: node SEQ-2e-postsavevesselcase.js [jsonObject]
//
// first source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-2e-postsavevesselcase');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;

var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;

var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;

var custfld1 = process.env.WC1_CUSTFLD1
var custfld2 = process.env.WC1_CUSTFLD2
var custfld3 = process.env.WC1_CUSTFLD3
 
// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}

var date = new Date().toGMTString();

// get JSON object from command line NOTE: quotes must be exactly as next line example
// {"\"groupId\"":"\"418f28a7-b9c9-4ae4-8530-819c61b1ca6c\"","\"entityType\"":"\"VESSEL\"","\"providerTypes\"":["\"WATCHLIST\""],"\"name\"":"\"Hydra\"","\"customFields\"":[],"\"secondaryFields\"":[{"\"typeId\"":"\"SFCT_7\"","\"value\"":"\"9362059\""}]}
if(process.argv[2] != undefined){
    jsonObject = process.argv[2];
}else{
// POST request with a Body
// create the JSON object first
jsonObject = JSON.stringify(
{  
   "groupId": groupid,
   "entityType":"VESSEL",
   "providerTypes":[  
      "WATCHLIST"
   ],
   "name":"Hydra",
   "customFields":[
      {  
         "typeId": custfld1,
         "value":"custom field 1 sample value"
      },
      {  
         "typeId": custfld2,
         "value":"custom field 2 sample value"
      },
      {  
         "typeId":custfld3,
         "value":"mandatory custom field sample value"
      }
   ],
   "secondaryFields":[  
      {  
         "typeId":"SFCT_7",
         "value":"9362059"
      }
   ]
}
);
}
var contentLength = unescape(encodeURIComponent(jsonObject)).length;
var dataToSign = "(request-target): post " + /v1/ + "cases\n" +
    "host: " + gatewayhost + "\n" +
    "date: " + date + "\n" +
    "content-type: " + "application/json" + "\n" + 
    "content-length: " + contentLength + "\n" +
    jsonObject;

var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey  + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\"" + hmac + "\"";
var postheaders = {
      'Date': date,
      'Content-Type': 'application/json',
      'Content-Length' : contentLength,
      'Authorization': authorisation
};

// options for POST cases
var optionspost = {
    host : gatewayhost, // here only the domain name - no http/https
    path : '/v1/cases', // the rest of the url with parameters if needed
    method : 'POST',
    headers : postheaders
};

var reqPost = https.request(optionspost, function(res) {
    debug("statusCode: ", res.statusCode);

    // create a buffer to fill with the response data 
    var body = "";
    res.on('data', function(d) {
        body += d;  //concatinate the 256 byte (default) chucks
        debug('GET result:\n');
        debug(d); // straight byte stream no formatting
        debug('\n\nCall completed');
    });
    res.on("end", function(){
        // note JSON.parse does not traverse sub-levels, so use a traverse() example
        debug(JSON.parse(body)); //now format the stream of bytes in the body to JSON style format and traverse
        process.stdout.write(body); //print out the reqreturn
   });
});

reqPost.write(jsonObject);
reqPost.end();
reqPost.on('error', function(e) {
    console.error(e);
});
