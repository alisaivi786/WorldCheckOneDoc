// SEQ-8-postauditlogforcase - HTTPS POST w/Body request & response
//
// synopsis: node SEQ-8-postauditlogforcase.js [casesystemid] [startdate:YYYYMMDD] [enddate:YYYY-MM-DD] [actionbyuserid:12345678-1234-1234-1234-1234567890AB]
//
// source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-8-postauditlogforcase');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");
var tools = require('./tools.js');

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;

var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;

var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;
var actiontype = process.env.WC1_ACTIONTYPE;
var actionbyuserid = process.env.WC1_ACTIONUSERID;

var datetime = require('node-datetime');
var dt = datetime.create(process.env.WC1_ENDDATE);
var startdate = process.env.WC1_STARTDATE;
var enddate = dt.format('Y-m-d');

// environment variables are used unless overridden by commandline args
// scan args for audit query settings
for (var i = 2, len = process.argv.length; i < len; i++) {
    debug('arg'+i+'='+process.argv[i]);

    if (process.argv[i].includes('startdate:')){
        startdate=process.argv[i].substring(10);
    } else if (process.argv[i].includes('enddate:')){
               enddate=process.argv[i].substring(8);
           } else if (process.argv[i].includes('actionbyuserid:')){
                      actionbyuserid=process.argv[i].substring(15);
                  } else if (process.argv[i].includes('actiontype:')){
                      actiontype=process.argv[i].substring(11);
                      } else { 
                             casesystemid = process.argv[i]; //casesystemid needs no field id
                          }
}

debug('casesystemid='+casesystemid);
debug('actionbyuserid='+actionbyuserid);
debug('actiontype='+actiontype);
debug('startdate='+startdate);
debug('enddate='+enddate);

// query must be one continuous stream (note: cr/lf are escaped)
jsonObject = JSON.stringify(
{
"query" : "actionType=in=("+actiontype+");\
actionedByUserId=in=("+actionbyuserid+");\
eventDate>"+startdate+";eventDate<"+enddate+"", 
"sort": [ { 
    "columnName": "eventDate",

    "order": "DESCENDING"
    } ]
});

debug(jsonObject);

// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}

var date = new Date().toGMTString();

var contentLength = jsonObject.length;
var dataToSign = "(request-target): post " + /v1/ + "cases/" + casesystemid + "/auditEvents\n" +
    "host: " + gatewayhost + "\n" +
    "date: " + date + "\n" +
    "content-type: " + "application/json" + "\n" + 
    "content-length: " + contentLength + "\n" +
    jsonObject;

var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey  + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\"" + hmac + "\"";
var postheaders = {
      'Date': date,
      'Content-Type': 'application/json',
      'Content-Length' : contentLength,
      'Authorization': authorisation
};

// options for POST cases
var optionspost = {
    host : gatewayhost, // here only the domain name - no http/https
    path : '/v1/cases/' + casesystemid + '/auditEvents', // the rest of the url with parameters if needed
    method : 'POST',
    headers : postheaders
};

// POST request
var reqPost = https.request(optionspost, function(res) {
    debug("statusCode: ", res.statusCode);
    //debug("headers: ", res.headers);
    // create a buffer to fill with the response data 
    var body = "";
    res.on('data', function(d) {
        body += d;  //concatinate the 256 byte (default) chucks
        //debug('result:\n');
        //debug(d); // straight byte stream no formatting
        //debug('\n\nCall completed');
    });
    res.on("end", function(){
        // note JSON.parse does not traverse sub-levels, so use a traverse() example
//         var reqreturn=JSON.parse(body);
//         if(process.env.DEBUG){
//             tools.traverse(reqreturn, ' '); //now format the stream of bytes in the body to JSON style format and traverse
//        }

        debug(JSON.parse(body)); //now format the stream of bytes in the body to JSON style format and traverse
        process.stdout.write(body); //print out the body
   });
});

reqPost.write(jsonObject);
reqPost.end();
reqPost.on('error', function(e) {
    console.error(e);
});
