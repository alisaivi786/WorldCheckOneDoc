// SEQ-3-getsystemidofcase - HTTPS GET request & response
//
// synopsis: node SEQ-3-getsystemidofcase.js [caseid]
//
// first source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-3-getsystemidofcase');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;

var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;

var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;

debug('argv[2]='+process.argv[2]);
if(process.argv[2] != undefined){
	caseid = process.argv[2];

}
// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}
var date = new Date().toGMTString();
var dataToSign = "(request-target): get " + /v1/ + "caseReferences\n" +
    "host: " + gatewayhost + "\n" +
    "date: " + date;
var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey  + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\"" + hmac + "\"";

// GET headers is just date & authorization, no body
var headers = {};
    headers = {
      'Date': date,
      'Authorization': authorisation
};

// options for GET
var optionsget = {
    host : gatewayhost, // here only the domain name - no http/https
    path : gatewayurl + 'caseReferences?caseId=' + caseid, // the rest of the url with parameters if needed
    method : 'GET',
    headers : headers
};

var reqGet = https.request(optionsget, function(res) {
     debug('statusCode:',res.statusCode);

     // create a buffer to fill with the response data 
    var body = "";

    res.on('data', function(d) {
        body += d;  //concatinate the 256 byte (default) chucks
        //debug('GET result:\n');
        //debug(d);
        //debug('\n\nCall completed');
    });
    res.on("end", function(){
        debug(JSON.parse(body)); //now format the stream of bytes in the body to JSON style format
        process.stdout.write(body); //return the body to stdout
    });
});
 
reqGet.end();
reqGet.on('error', function(e) {
    console.error(e);
});