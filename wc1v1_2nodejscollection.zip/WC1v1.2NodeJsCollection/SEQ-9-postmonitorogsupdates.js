// SEQ-9-postmonitorogsupdates - HTTPS POST w/Body request & response
//
// synopsis: node SEQ-9-postmonitorogsupdates.js [startdate:YYYY-MM-DD] [enddate:YYYY-MM-DD]
//
// first source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-9-postmonitorogsupdates');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;

var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;

var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;
 

var startdate = process.env.WC1_STARTDATE;
var enddate = process.env.WC1_ENDDATE;
var date = new Date().toGMTString();

var datetime = require('node-datetime');
var dt = datetime.create();
var enddate = dt.format('Y-m-d');



// environment variables are used unless overridden by commandline args
// scan args for audit query settings
for (var i = 2, len = process.argv.length; i < len; i++) {
    debug('arg'+i+'='+process.argv[i]);

    if (process.argv[i].includes('startdate:')){
        startdate=process.argv[i].substring(10);
    } else if (process.argv[i].includes('enddate:')){
               enddate=process.argv[i].substring(8);
           } 
}
debug('startdate='+startdate+' enddate='+enddate);

// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}


// query must be one continuous stream (note: cr/lf are escaped)
jsonObject = JSON.stringify(
{
"query": "updateDate>="+startdate+";updateDate<"+enddate+""}
);
var contentLength = unescape(encodeURIComponent(jsonObject)).length;
var dataToSign = "(request-target): post " + /v1/ + "cases/ongoingScreeningUpdates\n" +
    "host: " + gatewayhost + "\n" +
    "date: " + date + "\n" +
    "content-type: " + "application/json" + "\n" + 
    "content-length: " + contentLength + "\n" +
    jsonObject;
debug("jsonObject: ", jsonObject);
var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey  + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\"" + hmac + "\"";
var postheaders = {
      'Date': date,
      'Content-Type': 'application/json',
      'Content-Length' : contentLength,
      'Authorization': authorisation
};

// options for POST cases
var optionspost = {
    host : gatewayhost, // here only the domain name - no http/https
    path : '/v1/cases/ongoingScreeningUpdates', // the rest of the url with parameters if needed
    method : 'POST',
    headers : postheaders
};

var reqPost = https.request(optionspost, function(res) {
    debug("statusCode: ", res.statusCode);

    // create a buffer to fill with the response data 
    var body = "";
    res.on('data', function(d) {
        body += d;  //concatinate the 256 byte (default) chucks
        //debug('GET result:\n');
        //debug(d); // straight byte stream no formatting
        //debug('\n\nCall completed');
    });
    res.on("end", function(){
        // note JSON.parse does not traverse sub-levels, so use a traverse() example
        debug(JSON.parse(body)); //now format the stream of bytes in the body to JSON style format and traverse
        process.stdout.write(body); //print out the reqreturn
   });
});

reqPost.write(jsonObject);
reqPost.end();
reqPost.on('error', function(e) {
    console.error(e);
});
