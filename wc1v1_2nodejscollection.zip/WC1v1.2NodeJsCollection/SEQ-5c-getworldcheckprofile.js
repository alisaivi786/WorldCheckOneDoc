// SEQ-5c-getworldcheckprofile - HTTPS GET request & response  
//
// synopsis: node SEQ-5c-getworldcheckprofile.js [wc1profile]
//
// first source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-5c-getworldcheckprofile');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");
var tools = require('./tools.js');

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;

var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;

var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;
 

if(process.argv[2] != undefined){
	wc1profile = process.argv[2];

}
debug(wc1profile);
// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}
var date = new Date().toGMTString();
var dataToSign = "(request-target): get " + gatewayurl + "reference/profile/" + wc1profile + "\n" +      
    "host: " + gatewayhost + "\n" +     
    "date: " + date;
var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\"" + hmac + "\"";

// GET headers is just date & authorization, no body
var headers = {};
    headers = {
      'Date': date,
      'Authorization': authorisation
};

var optionsget = {
    host : gatewayhost, // here only the domain name - no http/https
    path : gatewayurl + 'reference/profile/' + wc1profile, // the rest of url with parameters if needed
    method : 'GET', // do GET
    headers : headers
};

var reqGet = https.request(optionsget, function(res) {
    console.log("statusCode: ", res.statusCode);
    //console.log("headers: ", res.headers);
    
    // create a buffer to fill with the response data 
    var body = "";

    res.on('data', function(d) {
           body += d;  //concatinate the 256 byte (default) chucks
        //debug('GET result:\n');
        //debug(d); // straight byte stream no formatting
        //debug('\n\nCall completed');
    });
    res.on("end", function(){
        // note JSON.parse does not traverse sub-levels, so use a traverse() example
        var reqreturn=JSON.parse(body);
        debug(tools.traverse (reqreturn, ' ')); //now format the stream of bytes in the body to JSON style format and traverse
        process.stdout.write(body); //print out the reqreturn
    });
 });

reqGet.end ();
reqGet.on('error', function(e) {
        console.error(e);
});
