// tools.js
// traverse()


tools = module.exports = {
// FOR DISPLAY ONLY - simple functions to traverse a JSON object string return request

    traverse:function(x, level) {
      if (isArray(x)) {
        traverseArray(x, level);
      } else if ((typeof x === 'object') && (x !== null)) {
             traverseObject(x, level);
             } else {
                 process.stdout.write(level + "\""+ x + '\",\n');
                 }
    }

};

    function isArray(o) {
        return Object.prototype.toString.call(o) === '[object Array]';
    };


    function traverseArray(arr, level) {
        process.stdout.write(level + "[");
        arr.forEach(function(x) {
          tools.traverse(x, level + "   ");
        });
        process.stdout.write(level + "  ]\n");
    };
    function traverseObject(obj, level) {
      console.log(level + "{");
      for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
          process.stdout.write(level + "  \"" + key + "\":");
          tools.traverse(obj[key], level);
        }
      }
      process.stdout.write(level + "}\n");
    };
