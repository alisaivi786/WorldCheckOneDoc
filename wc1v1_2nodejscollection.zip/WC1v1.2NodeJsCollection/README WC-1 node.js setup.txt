// World-Check One API
// node.js Collection of API requests
//
// To run the node.js WC-1 API requests, first download node.js
// https://nodejs.org/en/download/
// NOTE: The WC-1 node.js examples have been tested on the windows version of node.js only.
//
// Instructions for node.js World-Check One API REST requests
// Download the node.js api documentation
// https://nodejs.org/api/
//
// Setup node.js to run the WC-1 API requests
//
// Download and read Node Package Manager documentation
// https://docs.npmjs.com/getting-started/what-is-npm
//
// Now install the following packages needed to run the WC-1 API examples
// npm packages for request and authentication objects
// npm install dotenv, https, replaceall, mathjs, crypto-js, crypto-js/aes, crypto-js/sha256
//
// NOTE: you must rename .env.txt to .env for the js code to work.
// Review the .env file and use the Pilot server Sample account
// Start with SEQ-1a getgroups.js