// SEQ-5e-putresolveresults - HTTPS PUT w/Body request & response
//
// synopsis: node SEQ-5e-putresolveresults.js [casesystemid] [status:POSITIVE] [risk:LOW] [reason:"Full Match"] [resultid1 resultid2...]
//
// first source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-5e-putresolveresults');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;
var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;
var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;

var custfld1 = process.env.WC1_CUSTFLD1
var custfld2 = process.env.WC1_CUSTFLD2
var custfld3 = process.env.WC1_CUSTFLD3
 
var resultid=process.env.WC1_RESULTID;
var statusid=process.env.WC1_STATUSID;
var riskid=process.env.WC1_RISKID;
var reasonid=process.env.WC1_REASONID;
var resolutionremarkstr=process.env.WC1_RESOLUTIONREMARK;

var statusstr='POSSIBLE';
var riskstr='MEDIUM';
var reasonstr="Possible Match";

// positive match, low risk, full match
//var statusid="75ee5dec-cae6-421a-ba38-2ad5a5c98ace";
//var riskid="11ea8449-d365-475e-9a7b-532fc38cab7e";
//var reasonid="84595c00-6528-4fc8-9dad-38223d53e134";

var arg=3; // assumes casesystemid is arg[2]

// all commandline args are optional in []
// synopsis: node SEQ-5e-putresolveresults.js [casesystemid] [status:POSITIVE] [risk:LOW] [reason:"Full Match"] [resultid1 resultid2...]


if((process.argv[2] != undefined) && !process.argv[2].includes(':')){ // test if casesystemid first arg
	casesystemid = process.argv[2];
} else {
        arg=2; // no casesystemid in args, use default in env
    }
var resultids=[resultid]; //"45f6164b-d9a7-4232-9418-711923f2244e", "0a3687cf-58ba-1f43-9653-1a100003a234"

// environment variables are used unless overridden by commandline args
// scan args for resultids to overwrite the default
for (var i = arg,j=0, len = process.argv.length; i < len; i++) {
    console.log('arg'+i+'='+process.argv[i]);
 
    if (process.argv[i].includes('status:')){
        statusstr=process.argv[i].substring(7);
    } else if (process.argv[i].includes('risk:')){
               riskstr=process.argv[i].substring(5);
           } else if (process.argv[i].includes('reason:')){
                      reasonstr=process.argv[i].substring(7);
                  } else if (process.argv[i].includes('resolutionremark:')){
                          resolutionremarkstr=process.argv[i].substring(17);
                         } else {
                             resultids[j]= process.argv[i]; //resultids need no field id
                             j++;
                             }
}

// statobj should match the resolution toolkit output
var statobj = 
{
    "statuses": [
      {
        "id": "36604ead-d000-4111-ae10-e23d2bcfc7db",
        "label": "FALSE",
        "type": "FALSE"
      },
      {
        "id": "75ee5dec-cae6-421a-ba38-2ad5a5c98ace",
        "label": "POSITIVE",
        "type": "POSITIVE"
      },
      {
        "id": "a3e41773-23fb-4a03-84d6-e485126e071b",
        "label": "UNSPECIFIED",
        "type": "UNSPECIFIED"
      },
      {
        "id": "37371e33-9b64-427c-9f0f-284e2e8c4d27",
        "label": "POSSIBLE",
        "type": "POSSIBLE"
      }
    ],
    "risks": [
      {
        "id": "d7784825-91ec-4b96-8327-60a5463bb877",
        "label": "UNKNOWN",
        "type": null
      },
      {
        "id": "a50188e8-5a62-406d-86d7-b542020aa820",
        "label": "MEDIUM",
        "type": null
      },
      {
        "id": "11ea8449-d365-475e-9a7b-532fc38cab7e",
        "label": "LOW",
        "type": null
      },
      {
        "id": "0c14e442-b860-43e0-82b7-93b884fccbf9",
        "label": "HIGH",
        "type": null
      }
    ],
    "reasons": [
      {
        "id": "fd84450b-5a90-4b41-b37e-ff013f387411",
        "label": "No Match",
        "type": null
      },
      {
        "id": "84595c00-6528-4fc8-9dad-38223d53e134",
        "label": "Full Match",
        "type": null
      },
      {
        "id": "e44c1055-e6ef-43f9-8f27-fc9d7826d0a5",
        "label": "Possible Match",
        "type": null
      },
      {
        "id": "fdeea5c4-fe58-423b-a890-8cb67386813d",
        "label": "n/a",
        "type": null
      }
    ]
 };//end of statobj

for (var i = 0; i < statobj.statuses.length; i++) {
   if (statobj.statuses[i].label == statusstr){
      statusid=statobj.statuses[i].id
      debug(statobj.statuses[i].label+' = '+statobj.statuses[i].id);
   }
}
for (var i = 0; i < statobj.risks.length; i++) {
   if (statobj.risks[i].label == riskstr){
      riskid=statobj.risks[i].id
      debug(statobj.risks[i].label+' = '+statobj.risks[i].id);
   }
}
for (var i = 0; i < statobj.reasons.length; i++) {
   if (statobj.reasons[i].label == reasonstr){
      reasonid=statobj.reasons[i].id
      debug(statobj.reasons[i].label+' = '+statobj.reasons[i].id);
   }
}


debug('casesystemid='+casesystemid);
debug('statusid='+statusid);
debug('riskid='+riskid);
debug('reasonid='+reasonid);
debug('resultids='+resultids);
debug('resolutionremarkstr='+resolutionremarkstr);


// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}

var date = new Date().toGMTString();

// status    
//"label": "FALSE","id": "36604ead-d000-4111-ae10-e23d2bcfc7db"
//"label": "POSITIVE","id": "75ee5dec-cae6-421a-ba38-2ad5a5c98ace"
//"label": "UNSPECIFIED","id": "a3e41773-23fb-4a03-84d6-e485126e071b"
//"label": "POSSIBLE","id": "37371e33-9b64-427c-9f0f-284e2e8c4d27"

// risk 
//"label": "UNKNOWN","id": "d7784825-91ec-4b96-8327-60a5463bb877"
//"label": "MEDIUM","id": "a50188e8-5a62-406d-86d7-b542020aa820"
//"label": "LOW","id": "11ea8449-d365-475e-9a7b-532fc38cab7e"
//"label": "HIGH","id": "0c14e442-b860-43e0-82b7-93b884fccbf9"
        
//
// reason
//"label": "No Match","id": "fd84450b-5a90-4b41-b37e-ff013f387411"
//"label": "Full Match","id": "84595c00-6528-4fc8-9dad-38223d53e134"
//"label": "Possible Match","id": "e44c1055-e6ef-43f9-8f27-fc9d7826d0a5"
//"label": "n/a","id": "fdeea5c4-fe58-423b-a890-8cb67386813d"
        

// PUT request with a Body
// create the JSON object first
var jsonObject = JSON.stringify(
{
  "resultIds": resultids,
  "statusId": statusid,
  "riskId": riskid,
  "reasonId": reasonid,
  "resolutionRemark":resolutionremarkstr
});
//debug('jsonObject={"resultIds":["0a3687cf-58ba-1f43-9653-1a100003a234"],"statusId":"75ee5dec-cae6-421a-ba38-2ad5a5c98ace","riskId":"a50188e8-5a62-406d-86d7-b542020aa820","reasonId":"84595c00-6528-4fc8-9dad-38223d53e134","resolutionRemark":"Auto-Remark for the case"}');
debug('jsonObject='+jsonObject);

var contentLength = unescape(encodeURIComponent(jsonObject)).length;
var dataToSign = "(request-target): put " + /v1/ + "cases/" + casesystemid + "/results/resolution\n" +
    "host: " + gatewayhost + "\n" +
    "date: " + date + "\n" +
    "content-type: " + "application/json" + "\n" + 
    "content-length: " + contentLength + "\n" +
    jsonObject;

var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey  + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\"" + hmac + "\"";
var putheaders = {
      'Date': date,
      'Content-Type': 'application/json',
      'Content-Length' : contentLength,
      'Authorization': authorisation
};

// options for PUT cases
var optionsput = {
    host : gatewayhost, // here only the domain name - no http/https
    path : '/v1/cases/' + casesystemid + '/results/resolution', // the rest of the url with parameters if needed
    method : 'PUT',
    headers : putheaders
};

//console.info(optionsput);
var reqPut = https.request(optionsput, function(res) {
    debug("statusCode: ", res.statusCode);
    //debug("headers: ", res.headers);
    // no data gets returned 
});

reqPut.write(jsonObject);
reqPut.end();
reqPut.on('error', function(e) {
    console.error(e);
});
