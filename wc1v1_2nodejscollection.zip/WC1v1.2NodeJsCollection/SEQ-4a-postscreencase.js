// SEQ-4a-postscreenacase - POST HTTPS request & response
//
// synopsis: node SEQ-4a-postscreenacase.js [casesystemid]
//
// source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-4a-postscreenacase');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;

var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;

var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;
 
debug (process.argv[2]);
if(process.argv[2] != undefined){
	casesystemid = process.argv[2];

}
// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}

var date = new Date().toGMTString();
var dataToSign = "(request-target): post " + gatewayurl + "cases/" + casesystemid + "/screeningRequest\n" +      
    "host: " + gatewayhost + "\n" +     
    "date: " + date;
var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\"" + hmac + "\"";

// POST headers is just date & authorization, no body
var postheaders = {
      'Authorization': authorisation,
      'Date': date
};
// options for POST cases
var optionspost = {
    host : gatewayhost, // here only the domain name - no http/https
    path : gatewayurl + 'cases/' + casesystemid + '/screeningRequest', // the rest of url with parameters if needed
    method : 'POST', 
    headers : postheaders
};

var reqPost = https.request(optionspost, function(res) {
    console.log("statusCode: ", res.statusCode);

    // no data gets returned 
});
 
reqPost.end();
reqPost.on('error', function(e) {
    console.error(e);
});


