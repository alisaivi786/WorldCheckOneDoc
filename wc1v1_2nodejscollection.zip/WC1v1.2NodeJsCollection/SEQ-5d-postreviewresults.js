// SEQ-5d-postreviewresults - HTTPS POST w/Body request & response
//
// synopsis: node SEQ-5d-putresolveresults.js [casesystemid] [reviewremark:"Auto-Review"] [resultid1 resultid2...]
//
// first source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-5d-postreviewresults');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;
var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;
var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;

var resultid=process.env.WC1_RESULTID;
var statusid=process.env.WC1_STATUSID;
var riskid=process.env.WC1_RISKID;
var reasonid=process.env.WC1_REASONID;
var reviewremarkstr=process.env.WC1_REVIEWREMARK;

var resultids=[];
var arg=3; // assumes casesystemid is arg[2]



if((process.argv[2] != undefined) && !process.argv[2].includes(':')){ // test if casesystemid first arg
	casesystemid = process.argv[2];
} else {
        arg=2; // no casesystemid in args, use default in env
    }
var resultids=[resultid]; //"45f6164b-d9a7-4232-9418-711923f2244e", "0a3687cf-58ba-1f43-9653-1a100003a234"

// environment variables are used unless overridden by commandline args
// scan args for resultids to overwrite the default
for (var i = arg,j=0, len = process.argv.length; i < len; i++) {
    console.log('arg'+i+'='+process.argv[i]);
 
    if (process.argv[i].includes('reviewremark:')){
        reviewremarkstr=process.argv[i].substring(13);
    } else {
           resultids[j]= process.argv[i]; //resultids need no field id
           j++;
        }
}

debug('groupid='+groupid);
debug('casesystemid='+casesystemid);
debug('reviewremarkstr='+reviewremarkstr);
debug('resultids= '+JSON.stringify(resultids));


// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}

var date = new Date().toGMTString();

// create the JSON object first
jsonObject = JSON.stringify(
{
  "resultIds": resultids,
  "remark": reviewremarkstr
});

//debug(jsonObject);
var contentLength = unescape(encodeURIComponent(jsonObject)).length;
var dataToSign = "(request-target): put " + /v1/ + "cases/" + casesystemid + "/results/review\n" +
    "host: " + gatewayhost + "\n" +
    "date: " + date + "\n" +
    "content-type: " + "application/json" + "\n" + 
    "content-length: " + contentLength + "\n" +
    jsonObject;

var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey  + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\"" + hmac + "\"";
var putheaders = {
      'Date': date,
      'Content-Type': 'application/json',
      'Content-Length' : contentLength,
      'Authorization': authorisation
};

// options for PUT cases
var optionsput = {
    host : gatewayhost, // here only the domain name - no http/https
    path : '/v1/cases/' + casesystemid + '/results/review', 
    method : 'PUT',
    headers : putheaders
};

//console.info(optionsput);

var reqPut = https.request(optionsput, function(res) {
    debug("statusCode: ", res.statusCode);
    // no data gets returned 
});

reqPut.write(jsonObject);
reqPut.end();
reqPut.on('error', function(e) {
    console.error(e);
});
