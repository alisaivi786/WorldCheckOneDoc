// SEQ-6a-putenableogs - HTTPS PUT request & response
//
// synopsis: node SEQ-6a-putenableogs.js [casesystemid] 
// Status=204 OGS enabled
//
// first source the modules needed for request and authentication objects
var debug = require('debug')('SEQ-6a-putenableogs');
var https = require('https');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");

//Load the Environment variables from .env file
require('dotenv').config();
var gatewayhost = process.env.WC1_GATEWAYHOST;
var gatewayurl = process.env.WC1_GATEWAYURL;

var apikey = process.env.WC1_APIKEY;
var apisecretkey = process.env.WC1_APISECRETKEY;

var groupid = process.env.WC1_GROUPID;
var caseid = process.env.WC1_CASEID;
var casesystemid = process.env.WC1_CASESYSTEMID;
var wc1profile = process.env.WC1_PROFILE;
 
debug(process.argv[2]);
if(process.argv[2] != undefined){
	casesystemid = process.argv[2];

}
// declare the encrypt the authorization header using the signature
function generateAuthHeader(dataToSign){  
    var hash = CryptoJS.HmacSHA256(dataToSign,apisecretkey); 
    return hash.toString(CryptoJS.enc.Base64); 
}

var date = new Date().toGMTString();
var dataToSign = "(request-target): put " + gatewayurl + "cases/" + casesystemid + "/ongoingScreening\n" +      
    "host: " + gatewayhost + "\n" +     
    "date: " + date;
var hmac = generateAuthHeader(dataToSign);
var authorisation = "Signature keyId=\"" + apikey + "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\"" + hmac + "\"";

// PUT headers is just date & authorization, no body
var putheaders = {
      'Authorization': authorisation,
      'Date': date
};

var optionsput = {
    host : gatewayhost, // here only the domain name - no http/https
    path : gatewayurl + 'cases/' + casesystemid + '/ongoingScreening', // the rest of url with parameters if needed
    method : 'PUT', 
    headers : putheaders
};


var reqPut = https.request(optionsput, function(res) {
    debug("statusCode: ", res.statusCode);

    // no data gets returned 

});
 
reqPut.end();
reqPut.on('error', function(e) {
    console.error(e);
});


