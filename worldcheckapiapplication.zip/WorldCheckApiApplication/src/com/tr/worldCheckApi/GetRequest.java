package com.tr.worldCheckApi;

import java.util.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.databind.*;
import com.tr.logging.LogHelper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
//import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;

/**
 * This class using for calling all WorldCheck Get Request and fetching the
 * Results.
 * 
 * @author Shilpi Saha
 * 
 */
public class GetRequest {

	private final static Logger log = LogHelper.getLogger(GetRequest.class);

	private static Properties fromApiPropertyFile = LoadConfigFile
			.LoadApiPropFile();
	static GetRequest getRequest = new GetRequest();
	static String gatewayurl = fromApiPropertyFile.getProperty("Gatewayurl")
			.trim();
	static String gatewayhost = fromApiPropertyFile.getProperty("Gatewayhost")
			.trim();
	static String apikey = fromApiPropertyFile.getProperty("Apikey").trim();
	static String apisecret = fromApiPropertyFile.getProperty("Apisecret")
			.trim();
	static String groupid = fromApiPropertyFile.getProperty("Groupid").trim();
	static String httpsUrlForGroups = fromApiPropertyFile.getProperty(
			"HttpsUrlForGroups").trim();
	static String httpsUrlForCase = fromApiPropertyFile.getProperty(
			"HttpUrlForCase").trim();
	static String httpsUrl = fromApiPropertyFile.getProperty("HttpsUrl").trim();
	static String worldCheckProfileId = fromApiPropertyFile.getProperty(
			"WorldCheckProfileId").trim();
	static String httpsUrlForSingleGroup = fromApiPropertyFile.getProperty(
			"HttpsUrlForSingleGroup").trim();
	public static String generateAuthHeader(String dataToSign, String secret) {

		String hash = "";
		try {

			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(),
					"HmacSHA256");
			sha256_HMAC.init(secret_key);
			hash = Base64.encodeBase64String(sha256_HMAC.doFinal(dataToSign
					.getBytes()));
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return (hash);
	}

	/**
	 * This method is using for retrieve the all top level group information.
	 * 
	 * @throws IOException
	 */
	public static void processingGetTopLevelGroupRequest() throws IOException {
		log.info("Entering the processingGetTopLevelGroupRequest method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String dataToSign = "(request-target): get " + gatewayurl
					+ "groups\n" + "host: " + gatewayhost + "\n" + "date: "
					+ date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is......" + dataToSign);
			log.info("hmac is......" + dataToSign);

			HttpGet httpGet = new HttpGet(
					httpsUrlForSingleGroup);

			httpGet.addHeader("Authorization", authorisation);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("date", date);

			CloseableHttpResponse response = httpclient.execute(httpGet);

			try {

				HttpEntity entity = response.getEntity();
				log.info("response.getStatusLine is.........."
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				log.info("entity is......." + entity);
				log.info("json is......." + json);
				ObjectMapper mapper = new ObjectMapper();

				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is..........." + indented);

				EntityUtils.consume(entity);
			} catch (Exception e) {
				log.error(e.getMessage());
			} finally {
				response.close();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingGetTopLevelGroupRequest method");
	}

	/**
	 * The method is using for retrieve a particular group information based on
	 * that particular groupId
	 * 
	 * @throws IOException
	 */
	public static void processingGetSpecificGroup() throws IOException {
		log.info("Entering the processingGetSpecificGroup method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String dataToSign = "(request-target): get " + gatewayurl
					+ "groups/" + groupid + "\n" + "host: " + gatewayhost
					+ "\n" + "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is......" + dataToSign);
			log.info("hmac is......" + dataToSign);

			HttpGet httpGet = new HttpGet(httpsUrlForGroups + groupid);

			httpGet.addHeader("Authorization", authorisation);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("date", date);

			CloseableHttpResponse response = httpclient.execute(httpGet);

			try {

				HttpEntity entity = response.getEntity();
				log.info("response.getStatusLine is.........."
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				log.info("entity is......." + entity);
				log.info("json is......." + json);
				ObjectMapper mapper = new ObjectMapper();

				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is..........." + indented);

				EntityUtils.consume(entity);
			} catch (Exception e) {
				log.error(e.getMessage());
			} finally {
				response.close();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingGetSpecificGroup method");
	}

	/**
	 * The method is using for retrieve the case template for a particular
	 * groupId
	 * 
	 * @throws IOException
	 */
	public static void processingGetCaseTemplate() throws IOException {
		log.info("Entering the processingGetCaseTemplate method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String dataToSign = "(request-target): get " + gatewayurl
					+ "groups/" + groupid + "/caseTemplate\n" + "host: "
					+ gatewayhost + "\n" + "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is......" + dataToSign);
			log.info("hmac is......" + dataToSign);

			HttpGet httpGet = new HttpGet(httpsUrlForGroups + groupid
					+ "/caseTemplate");

			httpGet.addHeader("Authorization", authorisation);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("date", date);

			CloseableHttpResponse response = httpclient.execute(httpGet);

			try {

				HttpEntity entity = response.getEntity();
				log.info("response.getStatusLine is.........."
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				log.info("entity is......." + entity);
				log.info("json is......." + json);
				ObjectMapper mapper = new ObjectMapper();

				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is..........." + indented);

				EntityUtils.consume(entity);
			} catch (Exception e) {
				log.error(e.getMessage());
			} finally {
				response.close();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingGetCaseTemplate method");
	}

	/**
	 * The method is using for retrieve all world check iso country list.
	 * 
	 * @throws IOException
	 */
	public static void processingGetIsoCountryList() throws IOException {
		log.info("Entering the processingGetIsoCountryList method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String dataToSign = "(request-target): get " + gatewayurl
					+ "reference/countries\n" + "host: " + gatewayhost + "\n"
					+ "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is......" + dataToSign);
			log.info("hmac is......" + dataToSign);

			HttpGet httpGet = new HttpGet(httpsUrl + "reference/countries");

			httpGet.addHeader("Authorization", authorisation);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("date", date);

			CloseableHttpResponse response = httpclient.execute(httpGet);

			try {

				HttpEntity entity = response.getEntity();
				log.info("response.getStatusLine is.........."
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				log.info("entity is......." + entity);
				log.info("json is......." + json);
				ObjectMapper mapper = new ObjectMapper();

				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is..........." + indented);

				EntityUtils.consume(entity);
			} catch (Exception e) {
				log.error(e.getMessage());
			} finally {
				response.close();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingGetIsoCountryList method");
	}

	/**
	 * This method is using for retrieve the sources and providers information
	 * along with world check api's category information.
	 * 
	 * @throws IOException
	 */
	public static void processingGetListOfSourceProviders() throws IOException {
		log.info("Entering the processingGetListOfSourceProviders method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String dataToSign = "(request-target): get " + gatewayurl
					+ "reference/providers\n" + "host: " + gatewayhost + "\n"
					+ "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is......" + dataToSign);
			log.info("hmac is......" + dataToSign);

			HttpGet httpGet = new HttpGet(httpsUrl + "reference/providers");

			httpGet.addHeader("Authorization", authorisation);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("date", date);

			CloseableHttpResponse response = httpclient.execute(httpGet);

			try {

				HttpEntity entity = response.getEntity();
				log.info("response.getStatusLine is.........."
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				log.info("entity is......." + entity);
				log.info("json is......." + json);
				ObjectMapper mapper = new ObjectMapper();

				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is..........." + indented);

				EntityUtils.consume(entity);
			} catch (Exception e) {
				log.error(e.getMessage());
			} finally {
				response.close();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingGetListOfSourceProviders method");
	}

	/**
	 * The method is using for retrieve the resolution fields information like
	 * statuses,risks,reasons etc.
	 * 
	 * @throws IOException
	 */
	public static void processingGetRosolutionToolkitForGroup()
			throws IOException {
		log.info("Entering the processingGetRosolutionToolkitForGroup method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String dataToSign = "(request-target): get " + gatewayurl
					+ "groups/" + groupid + "/resolutionToolkit\n" + "host: "
					+ gatewayhost + "\n" + "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is......" + dataToSign);
			log.info("hmac is......" + dataToSign);

			HttpGet httpGet = new HttpGet(httpsUrlForGroups + groupid
					+ "/resolutionToolkit");

			httpGet.addHeader("Authorization", authorisation);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("date", date);

			CloseableHttpResponse response = httpclient.execute(httpGet);

			try {

				HttpEntity entity = response.getEntity();
				log.info("response.getStatusLine is.........."
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				log.info("entity is......." + entity);
				log.info("json is......." + json);
				ObjectMapper mapper = new ObjectMapper();

				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is..........." + indented);

				EntityUtils.consume(entity);
			} catch (Exception e) {
				log.error(e.getMessage());
			} finally {
				response.close();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingGetRosolutionToolkitForGroup method");
	}

	/**
	 * The method is using for retrieve world check profile information.
	 * 
	 * @throws IOException
	 */
	public static void processingGetWorldCheckProfile() throws IOException {
		log.info("Entering the processingGetWorldCheckProfile method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String dataToSign = "(request-target): get " + gatewayurl
					+ "reference/profile/" + worldCheckProfileId + "\n"
					+ "host: " + gatewayhost + "\n" + "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is......" + dataToSign);
			log.info("hmac is......" + dataToSign);

			HttpGet httpGet = new HttpGet(httpsUrl + "reference/profile/"
					+ worldCheckProfileId);

			httpGet.addHeader("Authorization", authorisation);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("date", date);

			CloseableHttpResponse response = httpclient.execute(httpGet);

			try {

				HttpEntity entity = response.getEntity();
				log.info("response.getStatusLine is.........."
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				log.info("entity is......." + entity);
				log.info("json is......." + json);
				ObjectMapper mapper = new ObjectMapper();

				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is..........." + indented);

				EntityUtils.consume(entity);
			} catch (Exception e) {
				log.error(e.getMessage());
			} finally {
				response.close();
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingGetWorldCheckProfile method");
	}

	public static void processingScreeningResult(String caseSystemId)
			throws IOException, JSONException {
		log.info("Entering the processingScreeningResult method");
		CloseableHttpClient httpclient1 = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);
			String gatewayurl = fromApiPropertyFile.getProperty("Gatewayurl")
					.trim();
			String gatewayhost = fromApiPropertyFile.getProperty("Gatewayhost")
					.trim();
			String apikey = fromApiPropertyFile.getProperty("Apikey").trim();
			String apisecret = fromApiPropertyFile.getProperty("Apisecret")
					.trim();

			String dataToSign = "(request-target): get " + gatewayurl
					+ "cases/" + caseSystemId + "/results\n" + "host: "
					+ gatewayhost + "\n" + "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			log.info("hmac is" + hmac);
			String authorisation1 = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is............." + dataToSign);

			log.info("authorisation1 is..........." + authorisation1);

			HttpGet httpGet = new HttpGet(
					httpsUrlForCase
							+ caseSystemId + "/results");

			httpGet.addHeader("Date", date);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("Authorization", authorisation1);

			// send the GET request
			CloseableHttpResponse response1 = httpclient1.execute(httpGet);

			try {

				HttpEntity entity1 = response1.getEntity();
				log.info("response is................"
						+ response1.getStatusLine());
				log.info("response is................" + response1.getEntity());
				String json = EntityUtils.toString(response1.getEntity());

				// json string returned
				log.info("json is........" + json);
				ObjectMapper mapper = new ObjectMapper();

				// printout in Pretty format
				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is.........." + indented);

				EntityUtils.consume(entity1);

			} finally {
				response1.close();
			}

		} finally {
			httpclient1.close();
		}
		log.info("Exiting the processingScreeningResult method");
	}

	public static void processingFetchingCaseDetails(String caseSystemId)
			throws IOException, JSONException {
		log.info("Entering the processingFetchingCaseDetails method");
		CloseableHttpClient httpclient1 = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);
			String gatewayurl = fromApiPropertyFile.getProperty("Gatewayurl")
					.trim();
			String gatewayhost = fromApiPropertyFile.getProperty("Gatewayhost")
					.trim();
			String apikey = fromApiPropertyFile.getProperty("Apikey").trim();
			String apisecret = fromApiPropertyFile.getProperty("Apisecret")
					.trim();

			String dataToSign = "(request-target): get " + gatewayurl
					+ "cases/" + caseSystemId + "\n" + "host: " + gatewayhost
					+ "\n" + "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			log.info("hmac is" + hmac);
			String authorisation1 = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is............." + dataToSign);

			log.info("authorisation1 is..........." + authorisation1);

			HttpGet httpGet = new HttpGet(
					httpsUrlForCase
							+ caseSystemId);

			httpGet.addHeader("Date", date);
			httpGet.addHeader("Cache-Control", "no-cache");
			httpGet.addHeader("Authorization", authorisation1);

			// send the POST request
			CloseableHttpResponse response1 = httpclient1.execute(httpGet);
			log.info("response1 is" + response1);
			try {

				HttpEntity entity1 = response1.getEntity();
				log.info("response is................"
						+ response1.getStatusLine());
				log.info("response is................" + response1.getEntity());
				String json = EntityUtils.toString(response1.getEntity());

				// json string returned
				log.info("json is........" + json);
				ObjectMapper mapper = new ObjectMapper();

				// printout in Pretty format
				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is.........." + indented);

				EntityUtils.consume(entity1);

			} finally {
				response1.close();
			}

		} finally {
			httpclient1.close();
		}
		log.info("Exiting the processingFetchingCaseDetails method");
	}

}
