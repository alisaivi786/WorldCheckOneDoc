package com.tr.worldCheckApi;

import java.io.IOException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Scanner;
import java.util.TimeZone;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tr.logging.LogHelper;

/**
 * This is the main class for world check one api which will call all get and
 * post methods.
 * 
 * @author Shilpi Saha
 * 
 */
public class WorldCheckApiMain {
	private final static Logger log = LogHelper
			.getLogger(WorldCheckApiMain.class);

	private static Properties fromApiPropertyFile = LoadConfigFile
			.LoadApiPropFile();
	static PostRequest postRequest = new PostRequest();

	static GetRequest getRequest = new GetRequest();
	static String gatewayurl = fromApiPropertyFile.getProperty("Gatewayurl")
			.trim();
	static String gatewayhost = fromApiPropertyFile.getProperty("Gatewayhost")
			.trim();
	static String apikey = fromApiPropertyFile.getProperty("Apikey").trim();
	static String apisecret = fromApiPropertyFile.getProperty("Apisecret")
			.trim();
	String groupid = fromApiPropertyFile.getProperty("Groupid").trim();

	public static void callingprocessingGetTopLevelGroupRequest()
			throws IOException, JSONException {

		getRequest.processingGetTopLevelGroupRequest();

	}

	public static void callingProcessingGetSpecificGroupRequest()
			throws IOException, JSONException {

		getRequest.processingGetSpecificGroup();

	}

	public static void callingProcessingGetCaseTemplate() throws IOException,
			JSONException {

		getRequest.processingGetCaseTemplate();

	}

	public static void callingProcessingGetIsoCountryList() throws IOException,
			JSONException {

		getRequest.processingGetIsoCountryList();

	}

	public static void callingProcessingGetListOfSourceProviders()
			throws IOException, JSONException {

		getRequest.processingGetListOfSourceProviders();

	}

	public static void callingProcessingGetWorldCheckProfile()
			throws IOException, JSONException {

		getRequest.processingGetWorldCheckProfile();

	}

	public static void callingProcessingGetRosolutionToolkitForGroup()
			throws IOException, JSONException {

		getRequest.processingGetRosolutionToolkitForGroup();

	}

	public static void callingCreateCaseRequest() throws IOException,
			JSONException {
		log.info("Entering the callingCreateCaseRequest method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		String caseSystemId = null;
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);

			String groupid = fromApiPropertyFile.getProperty("Groupid").trim();

			// create a JSON string
			// String jsonBody = fromApiPropertyFile.getProperty("JsonBody")
			// .trim();
			byte[] bytes = fromApiPropertyFile.getProperty("JsonBody")
					.getBytes(Charset.forName("UTF-8"));
			// JSONObject jo = new JSONObject(jsonBody);

			// String jlen = String.valueOf(jo.toString().length());
			String dataToSign = "(request-target): post " + gatewayurl
					+ "cases\n" + "host: " + gatewayhost + "\n" + "date: "
					+ date + "\n" + "content-type: " + "application/json"
					+ "\n" + "content-length: " + bytes.length + "\n"
					+ new String(bytes);

			String hmac = postRequest.generateAuthHeader(dataToSign, apisecret);
			log.info("hmac is" + hmac);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\""
					+ hmac + "\"";

			// log.info("jlen is.............." + jlen);
			log.info("dataToSign is............." + dataToSign);

			log.info("authorisation is..........." + authorisation);
			// String msg = jo.toString();

			HttpPost httpPost = new HttpPost(
					"https://rms-world-check-one-api-pilot.thomsonreuters.com/v1/cases");

			HttpEntity entity = new ByteArrayEntity(bytes);
			httpPost.setEntity(entity);

			httpPost.addHeader("Date", date);
			httpPost.addHeader("Cache-Control", "no-cache");
			httpPost.addHeader("Content-Type", "application/json");
			httpPost.addHeader("Authorization", authorisation);

			// send the POST request
			CloseableHttpResponse response = httpclient.execute(httpPost);
			log.info("response for case is" + response);
			try {

				HttpEntity entity1 = response.getEntity();
				log.info("response status line is................"
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());
				// System.out.println(entity1);
				// json string returned
				log.info("json is........" + json);
				ObjectMapper mapper = new ObjectMapper();

				// printout in Pretty format
				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is.........." + indented);

				String strs = indented;

				String[] arrOfStr = strs.split("caseSystemId");
				for (int i = 1; i <= arrOfStr.length - 1; i++) {
					String element = arrOfStr[i];
					caseSystemId = element.substring(element.indexOf(":") + 3,
							element.indexOf(",") - 1).trim();

				}
				System.out.println("caseSystemId is" + caseSystemId);

				EntityUtils.consume(entity1);

			} finally {
				response.close();
			}

		} finally {
			httpclient.close();
		}
		if ((caseSystemId != null)) {
			System.out
					.print("Found Case SystemId ...."
							+ caseSystemId
							+ "-- Would to like to continue for Option 10 to 13?Please enter YES/NO: ");
			String userChoice = new Scanner(System.in).nextLine();
			if (userChoice.equals("YES")) {
				try {
					optionMethodForAll(caseSystemId);
				} catch (Exception nfe) {
					nfe.getStackTrace();
				}
			} else {
				System.exit(0);
			}
		}
		log.info("Exiting the callingCreateCaseRequest method");
	}

	public static void callingProcessingScreeningRequest(String caseSystemId)
			throws IOException, JSONException {
		postRequest.processingScreeningRequest(caseSystemId);
	}

	public static void callingProcessingScreeningResult(String caseSystemId)
			throws IOException, JSONException {
		getRequest.processingScreeningResult(caseSystemId);
	}

	public static void callingProcessingFetchingCaseDetails(String caseSystemId)
			throws IOException, JSONException {
		getRequest.processingFetchingCaseDetails(caseSystemId);
	}

	public static void callingProcessingAuditLog(String caseSystemId)
			throws IOException, JSONException {
		postRequest.processingAuditLog(caseSystemId);
	}

	public static void optionMethodForAll(String caseSystemId)
			throws IOException, JSONException {
		System.out.println("Press 10 Screen A Case ");
		System.out.println("Press 11 Get screening Results");
		System.out.println("Press 12 Get full case details");

		System.out.println("Press 13 Retrieve The Audit Log For A Case");
		System.out.println("Press 14 Exit");
		System.out.print("Please enter your input: ");
		String userInput = new Scanner(System.in).nextLine();
		int number = 10;

		try {

			number = Integer.parseInt(userInput);
			if (number > 14 || number < 10) {

				System.out.println("Invalid Selection FOR optionmethodall");
				optionMethodForAll(caseSystemId);

			}

			switch (number) {
			case 10:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingScreeningRequest(caseSystemId);
				log.info("Completed The Screening the Case");
				System.out.println("Completed The Screening the Case");
				optionMethodForAll(caseSystemId);

			case 11:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingScreeningResult(caseSystemId);
				log.info("Completed The fetching Screening Result");
				System.out.println("Completed The fetching Screening Result");
				optionMethodForAll(caseSystemId);
				break;

			case 12:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingFetchingCaseDetails(caseSystemId);
				log.info("Completed The fetching case details");
				System.out.println("Completed The fetching case details");
				optionMethodForAll(caseSystemId);
				break;
			case 13:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingAuditLog(caseSystemId);
				
				log.info("Completed The fetching Audit Log");
				System.out.println("Completed The fetching Audit Log");
				optionMethodForAll(caseSystemId);
				break;
			case 14:
				System.exit(0);
			}
		} catch (NumberFormatException nfe) {

			System.out.println("Invalid No." + nfe.getMessage());
			log.error(nfe.getStackTrace());

		}
	}

	public static void optionMethod() throws IOException, JSONException {
		LogHelper.entering(log, "optionMethod");
		String userInput = new Scanner(System.in).nextLine();
		int number = 0;

		try {

			number = Integer.parseInt(userInput);

			if (number > 9 || number < 1) {

				System.out.println("Invalid Selection");
				optionMethod();

			}

			switch (number) {
			case 1:
				System.out.println("In Progress");
				log.info("In Progress");
				callingprocessingGetTopLevelGroupRequest();

				log.info("Completed The fetching all top level groupId");
				System.out
						.println("Completed The fetching all top level groupId");

				break;
			case 2:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingGetSpecificGroupRequest();
				log.info("Completed The fetching specific groupId");
				System.out.println("Completed The fetching specific groupId");

				break;

			case 3:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingGetCaseTemplate();
				log.info("Completed The fetching case template");
				System.out.println("Completed The fetching case template");

				break;
			case 4:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingGetIsoCountryList();
				log.info("Completed The fetching ISO Country List");
				System.out.println("Completed The fetching ISO Country List");

				break;
			case 5:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingGetListOfSourceProviders();
				log.info("Completed The fetching List Of Source Providers");
				System.out
						.println("Completed The fetching List Of Source Providers");

				break;
			case 6:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingGetRosolutionToolkitForGroup();
				log.info("Completed The fetching Resolution Toolkit");
				System.out.println("Completed The fetching Resolution Toolkit");

				break;
			case 7:
				System.out.println("In Progress");
				log.info("In Progress");
				callingProcessingGetWorldCheckProfile();
				log.info("Completed The fetching World Check Profile");
				System.out
						.println("Completed The fetching World Check Profile");

				break;

			case 8:
				System.out.println("In Progress");
				log.info("In Progress");
				callingCreateCaseRequest();
				log.info("Completed The Creation of Case");
				System.out.println("Completed The Creation of Case");
				System.exit(0);
			case 9:
				System.exit(0);
			default:
				System.out.println("!!Please select input from the list!!");
				break;
			}

		} catch (NumberFormatException nfe) {

			System.out.println("Invalid No." + nfe.getMessage());
			log.error(nfe.getStackTrace());

		}

		LogHelper.exiting(log, "optionMethod");
	}

	public static void main(String[] args) throws IOException, JSONException {
		PropertyConfigurator.configure("./properties/log4j.properties");
		System.out.println("Press 1 Get Top Level Groups ");
		System.out.println("Press 2 Get A Specific Group By ID ");
		System.out.println("Press 3 Get The Case Template For A Group ");
		System.out.println("Press 4 Get ISO Country List ");
		System.out.println("Press 5 Get A List Of source Providers");
		System.out.println("Press 6 Get The Resolution Toolkit For A Group ");
		System.out.println("Press 7 Get WorlCheck Profile");
		System.out
				.println("Press 8 Create A Case AND Processing 10 to 13 based on user Option");
		System.out.println("Press 9 For Exit");
		System.out.print("Please enter your input: ");

		optionMethod();

	}
}
