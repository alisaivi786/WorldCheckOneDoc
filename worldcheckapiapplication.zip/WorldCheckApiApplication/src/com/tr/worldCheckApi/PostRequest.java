package com.tr.worldCheckApi;

import org.json.*;

import java.util.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.databind.*;
import com.tr.logging.LogHelper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/** This class is using for all world check api post request.
 * @author Shilpi Saha
 *
 */
public class PostRequest {
	private final static Logger log = LogHelper.getLogger(PostRequest.class);

	private static Properties fromApiPropertyFile = LoadConfigFile
			.LoadApiPropFile();
	static String httpsUrlForSingleCase = fromApiPropertyFile.getProperty(
			"HttpUrlSingleCase").trim();
	static String httpsUrlForCase = fromApiPropertyFile.getProperty(
			"HttpUrlForCase").trim();
	public static String generateAuthHeader(String dataToSign, String secret) {
		PropertyConfigurator.configure("./properties/log4j.properties");
		String hash = "";
		try {

			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(),
					"HmacSHA256");
			sha256_HMAC.init(secret_key);
			hash = Base64.encodeBase64String(sha256_HMAC.doFinal(dataToSign
					.getBytes()));
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return (hash);
	}

	/**
	 * The method is using for create a case.
	 * 
	 * @throws IOException
	 * @throws JSONException
	 */
	public static void processingCreateCaseRequest() throws IOException,
			JSONException {
		log.info("Entering the processingCreateCaseRequest method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		String caseSystemId = null;
		
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);
			String gatewayurl = fromApiPropertyFile.getProperty("Gatewayurl")
					.trim();
			String gatewayhost = fromApiPropertyFile.getProperty("Gatewayhost")
					.trim();
			String apikey = fromApiPropertyFile.getProperty("Apikey").trim();
			String apisecret = fromApiPropertyFile.getProperty("Apisecret")
					.trim();
			String groupid = fromApiPropertyFile.getProperty("Groupid").trim();

			// create a JSON string
			String jsonBody = fromApiPropertyFile.getProperty("JsonBody")
					.trim();

			JSONObject jo = new JSONObject(jsonBody);

			String jlen = String.valueOf(jo.toString().length());
			String dataToSign = "(request-target): post " + gatewayurl
					+ "cases\n" + "host: " + gatewayhost + "\n" + "date: "
					+ date + "\n" + "content-type: " + "application/json"
					+ "\n" + "content-length: " + jlen + "\n" + jo;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			log.info("hmac is" + hmac);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\""
					+ hmac + "\"";

			log.info("jlen is.............." + jlen);
			log.info("dataToSign is............." + dataToSign);

			log.info("authorisation is..........." + authorisation);
			String msg = jo.toString();

			HttpPost httpPost = new HttpPost(
					httpsUrlForSingleCase);

			HttpEntity entity = new StringEntity(msg);
			httpPost.setEntity(entity);

			httpPost.addHeader("Date", date);
			httpPost.addHeader("Cache-Control", "no-cache");
			httpPost.addHeader("Content-Type", "application/json");
			httpPost.addHeader("Authorization", authorisation);

			// send the POST request
			CloseableHttpResponse response = httpclient.execute(httpPost);
			log.info("response for case is" + response);
			try {

				HttpEntity entity1 = response.getEntity();
				log.info("response status line is................"
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());

				log.info("json is........" + json);
				ObjectMapper mapper = new ObjectMapper();

				// printout in Pretty format
				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				log.info("indented is.........." + indented);

				String strs = indented;

				String[] arrOfStr = strs.split("caseSystemId");
				for (int i = 1; i <= arrOfStr.length - 1; i++) {
					String element = arrOfStr[i];
					caseSystemId = element.substring(element.indexOf(":") + 3,
							element.indexOf(",") - 1).trim();

				}

				EntityUtils.consume(entity1);

			} finally {
				response.close();
			}

		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingCreateCaseRequest method");
	}

	/**
	 * The method is using for screening a case based on caseSystemId.
	 * 
	 * @param caseSystemId
	 * @throws IOException
	 * @throws JSONException
	 */
	public  void processingScreeningRequest(String caseSystemId)
			throws IOException, JSONException {
		log.info("Entering the processingScreeningRequest method");
		CloseableHttpClient httpclient1 = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);
			String gatewayurl = fromApiPropertyFile.getProperty("Gatewayurl")
					.trim();
			String gatewayhost = fromApiPropertyFile.getProperty("Gatewayhost")
					.trim();
			String apikey = fromApiPropertyFile.getProperty("Apikey").trim();
			String apisecret = fromApiPropertyFile.getProperty("Apisecret")
					.trim();

			String screeningPath = fromApiPropertyFile.getProperty(
					"Screening_Path").trim();
			String dataToSign = "(request-target): post " + gatewayurl
					+ "cases/" + caseSystemId + "/screeningRequest\n"
					+ "host: " + gatewayhost + "\n" + "date: " + date;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			log.info("hmac is" + hmac);
			String authorisation1 = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date\",signature=\""
					+ hmac + "\"";

			log.info("dataToSign is............." + dataToSign);

			log.info("authorisation1 is..........." + authorisation1);

			HttpPost httpPost1 = new HttpPost(
					httpsUrlForCase
							+ caseSystemId + screeningPath);

			httpPost1.addHeader("Date", date);
			httpPost1.addHeader("Cache-Control", "no-cache");
			httpPost1.addHeader("Authorization", authorisation1);

			// send the POST request
			CloseableHttpResponse response1 = httpclient1.execute(httpPost1);
			log.info("response stsus line is........."
					+ response1.getStatusLine());
			try {

				HttpEntity entity1 = response1.getEntity();

				EntityUtils.consume(entity1);

			} finally {
				response1.close();
			}

		} finally {
			httpclient1.close();
		}
		log.info("Exiting the processingScreeningRequest method");
	}

	/**
	 * The method is using for count the total value of screening for a
	 * particular caseSystemId
	 * 
	 * @param caseSystemId
	 * @throws IOException
	 * @throws JSONException
	 */
	public  void processingAuditLog(String caseSystemId)
			throws IOException, JSONException {
		log.info("Entering the processingAuditLog method");
		CloseableHttpClient httpclient = HttpClients.createDefault();
		try {
			Date now = new Date();

			// format for date string Mon, 27 Mar 2017 15:19:36 GMT
			DateFormat df = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
			df.setTimeZone(TimeZone.getTimeZone("GMT"));

			String date = df.format(now);
			String gatewayurl = fromApiPropertyFile.getProperty("Gatewayurl")
					.trim();
			String gatewayhost = fromApiPropertyFile.getProperty("Gatewayhost")
					.trim();
			String apikey = fromApiPropertyFile.getProperty("Apikey").trim();
			String apisecret = fromApiPropertyFile.getProperty("Apisecret")
					.trim();

			// create a JSON string
			String jsonBody = fromApiPropertyFile.getProperty("AuditQuery")
					.trim();

			JSONObject jo = new JSONObject(jsonBody);

			String jlen = String.valueOf(jo.toString().length());
			String dataToSign = "(request-target): post " + gatewayurl
					+ "cases/" + caseSystemId + "/auditEvents\n" + "host: "
					+ gatewayhost + "\n" + "date: " + date + "\n"
					+ "content-type: " + "application/json" + "\n"
					+ "content-length: " + jlen + "\n" + jo;

			String hmac = generateAuthHeader(dataToSign, apisecret);
			log.info("hmac is" + hmac);
			String authorisation = "Signature keyId=\""
					+ apikey
					+ "\",algorithm=\"hmac-sha256\",headers=\"(request-target) host date content-type content-length\",signature=\""
					+ hmac + "\"";

			log.info("jlen is.............." + jlen);
			log.info("dataToSign is............." + dataToSign);

			log.info("authorisation is..........." + authorisation);
			String msg = jo.toString();

			HttpPost httpPost = new HttpPost(
					httpsUrlForCase
							+ caseSystemId + "/auditEvents");

			HttpEntity entity = new StringEntity(msg);
			httpPost.setEntity(entity);

			httpPost.addHeader("Date", date);
			httpPost.addHeader("Cache-Control", "no-cache");
			httpPost.addHeader("Content-Type", "application/json");
			httpPost.addHeader("Authorization", authorisation);

			// send the POST request
			CloseableHttpResponse response = httpclient.execute(httpPost);
			log.info("response for case is" + response);
			try {

				HttpEntity entity1 = response.getEntity();
				log.info("response status line is................"
						+ response.getStatusLine());

				String json = EntityUtils.toString(response.getEntity());

				log.info("json is........" + json);
				ObjectMapper mapper = new ObjectMapper();

				// printout in Pretty format
				Object jsonObj = mapper.readValue(json, Object.class);
				String indented = mapper.writerWithDefaultPrettyPrinter()
						.writeValueAsString(jsonObj);
				System.out.println("indented is.........." + indented);

				String strs = indented;

				String[] arrOfStr = strs.split("caseSystemId");
				for (int i = 1; i <= arrOfStr.length - 1; i++) {
					String element = arrOfStr[i];
					caseSystemId = element.substring(element.indexOf(":") + 3,
							element.indexOf(",") - 1).trim();

				}

				EntityUtils.consume(entity1);

			} finally {
				response.close();
			}

		} finally {
			httpclient.close();
		}
		log.info("Exiting the processingAuditLog method");
	}

}