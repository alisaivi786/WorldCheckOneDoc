package com.tr.worldCheckApi;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * ===================================================================== File :
 * LoadConfigFile.java<br>
 * Package : com.tr.openapi.export <br>
 * <b>LoadConfigFile:<b><br>
 * This class is using for read properties file for system.
 * 
 * @author Shilpi Saha
 *         ==============================================================
 *         =============
 * 
 */

public class LoadConfigFile {
	static Logger log = Logger.getLogger(LoadConfigFile.class.getName());

	public static Properties LoadApiPropFile() {
		final Properties configProp = new Properties();

		try {
			
			
			FileInputStream xmlCofigFile = new FileInputStream(
					"./properties/Api.properties");
			ClassLoader.class.getResourceAsStream("./properties/Api.properties");
			configProp.load(new InputStreamReader(xmlCofigFile, Charset.forName("UTF-8")));
			//configProp.load(xmlCofigFile);
		} catch (IOException e1) {
			log.error("Unable to load XMLConfig.properties file" + e1);
			e1.printStackTrace();
		}
		return configProp;
	}

	

}
