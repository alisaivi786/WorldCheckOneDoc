package com.tr.logging;

 


import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This class gives basic functionalities of log4j logging.
 * 
 * @author Shilpi Saha
 */
public abstract class LogHelper {

    /**
     * Enter method prefix.
     */
    private static final String ENTER_PREFIX = " ENTERING METHOD : ";

    /**
     * Exit method prefix.
     */
    private static final String EXIT_PREFIX = " EXITING METHOD : ";

    /**
     * Parameter prefix.
     */
    private static final String PARAM_PREFIX = " PARAM";

    /**
     * Return value prefix.
     */
    private static final String RETURN_PREFIX = " RETURN VALUE = ";

    /**
     * Default constructor.
     */
    private LogHelper() {

        /*
         * Private Constructor to prevent instantiation of the class.
         */
    }

    /**
     * @param clazz
     *            class name to be logged.
     * @return Logger instance.
     */
   
    public static Logger getLogger(final Class clazz) {

        return Logger.getLogger(clazz);
    }

    /**
     * @param name
     *            name of the class to be logged.
     * @return Logger instance.
     */
    public static Logger getLogger(final String name) {

        return Logger.getLogger(name);
    }

    /**
     * defines method entering.
     * 
     * @param logger
     *            logger instance.
     * @param methodName
     *            method name.
     */
    public static void entering(final Logger logger,
        final String methodName) {

        logger.log(Level.DEBUG, LogHelper.getEnterMethodLogStr(
            methodName, null), null);
    }

    
    
   
  

   
    /**
     * Logs the given string as an error message.
     * 
     * @param message
     *            the message that needs to be logged.
     */
    public static void error(final Logger logger,final String message){
    	logger.log(Level.DEBUG, LogHelper.getEnterMethodLogStr(
       		  message, null), null);
    }

    
    
    
    /**
     * Defines method entering.
     * 
     * @param logger
     *            logger instance.
     * @param methodName
     *            method name.
     * @param param1
     *            method argument.
     */
    public static void entering(final Logger logger,
        final String methodName, final Object param1) {

        Object[] params = {param1};

        logger.log(Level.DEBUG, LogHelper.getEnterMethodLogStr(
            methodName, params), null);
    }

    /**
     * Defines method entering.
     * 
     * @param logger
     *            logger instance.
     * @param methodName
     *            method name.
     * @param param1
     *            method argument0.
     * @param param2
     *            method argument1.
     */
    public static void entering(final Logger logger,
        final String methodName, final Object param1,
        final Object param2) {

        Object[] params = {param1, param2};

        logger.log(Level.DEBUG, LogHelper.getEnterMethodLogStr(
            methodName, params), null);
    }

    /**
     * Defines method entering.
     * 
     * @param logger
     *            logger instance.
     * @param methodName
     *            method name
     * @param param1
     *            argument0.
     * @param param2
     *            argument1.
     * @param param3
     *            argument2.
     */
    public static void entering(final Logger logger,
        final String methodName, final Object param1,
        final Object param2, final Object param3) {

        Object[] params = {param1, param2, param3};

        logger.log(Level.DEBUG, LogHelper.getEnterMethodLogStr(
            methodName, params), null);
    }

    /**
     * Defines method entering.
     * 
     * @param logger
     *            logger instance.
     * @param methodName
     *            method name
     * @param param1
     *            argument0.
     * @param param2
     *            argument1.
     * @param param3
     *            argument2.
     */
    public static void entering(final Logger logger,
        final String methodName, final String param1,
        final String param2, final Class[] param3, final Object[] param4) {

        Object[] params = {param1, param2, param3};

        logger.log(Level.DEBUG, LogHelper.getEnterMethodLogStr(
            methodName, params), null);
    }

    /**
     * Defines method exiting.
     * 
     * @param logger
     *            logger instance
     * @param methodName
     *            method name
     */
    public static void exiting(final Logger logger,
        final String methodName) {

        StringBuffer buf = new StringBuffer();
        buf.append(LogHelper.EXIT_PREFIX);
        buf.append(methodName + "(..)");

        logger.log(Level.DEBUG, buf.toString(), null);

    }

    /**
     * Defines method exiting.
     * 
     * @param logger
     *            logger instance
     * @param methodName
     *            method name
     * @param retVal
     *            return values
     */
    public static void exiting(final Logger logger,
        final String methodName, final Object retVal) {

        StringBuffer buf = new StringBuffer();
        buf.append(LogHelper.EXIT_PREFIX);
        buf.append(methodName + "(..)");
        buf.append(LogHelper.RETURN_PREFIX);
        buf.append("[ ");
        buf.append(retVal);
        buf.append(" ]");

        logger.log(Level.DEBUG, buf.toString(), null);

    }

    /**
     * Defines method exiting.
     * 
     * @param logger
     *            logger instance
     * @param methodName
     *            method name
     * @param retVal
     *            return values
     */
    
    public static void exiting(final Logger logger, final String methodName,
            final boolean retVal) {

        StringBuffer buf = new StringBuffer();
        buf.append(LogHelper.EXIT_PREFIX);
        buf.append(methodName + "(..)");
        buf.append(LogHelper.RETURN_PREFIX);
        buf.append("[ ");
        buf.append(retVal);
        buf.append(" ]");

        logger.log(Level.DEBUG, buf.toString(), null);

    }
    
    /**
     * Defines method exiting.
     * 
     * @param logger
     *            logger instance
     * @param methodName
     *            method name
     * @param retVal
     *            return values
     */
    public static void exiting(final Logger logger,
            final String methodName, final double retVal) {

            StringBuffer buf = new StringBuffer();
            buf.append(LogHelper.EXIT_PREFIX);
            buf.append(methodName + "(..)");
            buf.append(LogHelper.RETURN_PREFIX);
            buf.append("[ ");
            buf.append(retVal);
            buf.append(" ]");

            logger.log(Level.DEBUG, buf.toString(), null);
    }

    /**
     * Formats the log statements.
     * 
     * @param methodName
     *            method name
     * @param params
     *            method arguments.
     * @return formatted string
     */
    private static String getEnterMethodLogStr(final String methodName,
        final Object[] params) {

        StringBuffer buf = new StringBuffer(LogHelper.ENTER_PREFIX);
        buf.append(methodName + "(..)");

        if (params != null) {
            for (int i = 0; i < params.length; i++) {
                if (i > 0 && i != params.length) {
                    buf.append(",");
                }

                buf.append(LogHelper.PARAM_PREFIX);
                buf.append(i + 1);
                buf.append(" = [");
                buf.append(params[i]);
                buf.append("]");

            } // end for

        } // end if

        return buf.toString();

    }

 
}
